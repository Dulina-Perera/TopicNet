# backend/app/models/__init__.py

from .node import Node
